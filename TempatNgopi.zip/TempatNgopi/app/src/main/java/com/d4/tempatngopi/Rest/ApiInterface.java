package com.d4.tempatngopi.Rest;


import com.d4.tempatngopi.Model.GetPlace;


import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface ApiInterface {
    @GET("getPlace")
    Call<GetPlace> getPlace();

    @Multipart
    @POST("addPlace")
    Call<GetPlace> addPlace(
            @Part MultipartBody.Part image,
            @Part("name") RequestBody name,
            @Part("location") RequestBody location,
            @Part("description") RequestBody description,
            @Part("rating") RequestBody rating
    );



}
