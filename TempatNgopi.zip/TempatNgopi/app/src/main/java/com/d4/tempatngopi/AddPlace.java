package com.d4.tempatngopi;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.d4.tempatngopi.Model.GetPlace;
import com.d4.tempatngopi.R;
import com.d4.tempatngopi.Rest.ApiClient;
import com.d4.tempatngopi.Rest.ApiInterface;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Calendar;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddPlace extends AppCompatActivity {

    EditText tvName,tvDescription,tvRating,tvLocation;
    Button btnAddPlace,btnBack,btnFoto;
    ImageView ivPlace;
    public Uri filePath;
    Intent mIntent;
    String pathImage="";
    Context mContext;
    private static final int PICK_IMAGE_REQUEST = 234;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = getApplicationContext();
        setContentView(R.layout.activity_add_place);
        tvName = findViewById(R.id.etName);
        tvDescription = findViewById(R.id.etDescription);
        tvLocation = findViewById(R.id.etLocation);
        tvRating = findViewById(R.id.etRating);
        ivPlace = findViewById(R.id.ivPlace);
        btnAddPlace = findViewById(R.id.btnAddPlace);
        btnBack = findViewById(R.id.btnBack);
        btnFoto = findViewById(R.id.btnFoto);
        Glide.with(mContext).load(R.drawable.default_user).into(ivPlace);

        btnFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               mintaPermissions();
            }
        });

         btnAddPlace.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 addPlace();
             }
         });

    }

    private void addPlace() {
        ApiInterface mApiInterface = ApiClient.getClient().create(ApiInterface.class);
        MultipartBody.Part body = null;
        if (!pathImage.isEmpty()){
            // Buat file dari image yang dipilih
            File file = new File(pathImage);

            // Buat RequestBody instance dari file
            RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpg"), file);

            // MultipartBody.Part digunakan untuk mendapatkan nama file
            body = MultipartBody.Part.createFormData("image", file.getName(),
                    requestFile);
        }
        RequestBody reqNama = MultipartBody.create(MediaType.parse("multipart/form-data"),
                (tvName.getText().toString().isEmpty())?"":tvName.getText().toString());
        RequestBody reqLocation = MultipartBody.create(MediaType.parse("multipart/form-data"),
                (tvLocation.getText().toString().isEmpty())?"":tvLocation.getText().toString());
        RequestBody reqDescription = MultipartBody.create(MediaType.parse("multipart/form-data"),
                (tvDescription.getText().toString().isEmpty())?"":tvDescription.getText().toString());
        RequestBody reqRating = MultipartBody.create(MediaType.parse("multipart/form-data"),
                (tvRating.getText().toString().isEmpty())?"":tvRating.getText().toString());

        Call<GetPlace> mAddPlace = mApiInterface.addPlace(body,reqNama,reqLocation,reqDescription,reqRating);
        mAddPlace.enqueue(new Callback<GetPlace>() {
            @Override
            public void onResponse(Call<GetPlace> call, Response<GetPlace> response) {
                if(response.body().getStatus()=="success"){
                    Toast.makeText(mContext,
                            "Add Place Success",
                            Toast.LENGTH_SHORT)
                            .show();
                    Intent i = new Intent(mContext,MainActivity.class);
                    mContext.startActivity(i);
                }
            }

            @Override
            public void onFailure(Call<GetPlace> call, Throwable t) {
                Intent i = new Intent(mContext,MainActivity.class);
                mContext.startActivity(i);
            }
        });
    }


    private void mintaPermissions() {
        Dexter.withActivity(this)
                .withPermissions(
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.CAMERA)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // Cek apakah semua permission yang diperlukan sudah diijinkan
                        if (report.areAllPermissionsGranted()) {
                            Toast.makeText(getApplicationContext(),
                                    "Semua permissions diijinkan!", Toast.LENGTH_SHORT).show();
                            tampilkanFotoDialog();
                        }

                        // Cek apakah ada permission yang tidak diijinkan
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // Info user untuk mengubah setting permission
                            tampilkanSettingsDialog();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(
                            List<com.karumi.dexter.listener.PermissionRequest> permissions,
                            PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(),
                                "Error occurred! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Jika tidak ada image yang dipilih maka return
        if (resultCode == RESULT_CANCELED) {
            return;
        }

        // Jika request berasal dari Gallery
        if (requestCode == 13) {
            if (data != null) {
                Uri contentURI = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), contentURI);
                    pathImage = simpanImage(bitmap);
                    Toast.makeText(mContext, "Foto berhasil di-load!", Toast.LENGTH_SHORT).show();

                    Glide.with(mContext).load(new File(pathImage)).into(ivPlace);

                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(mContext, "Foto gagal di-load!", Toast.LENGTH_SHORT).show();
                }
            }

            // Jika request dari Camera
        } else if (requestCode == 16) {
            Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
            pathImage = simpanImage(thumbnail);
            Toast.makeText(mContext, "Foto berhasil di-load dari Camera!", Toast.LENGTH_SHORT)
                    .show();

            Glide.with(mContext).load(new File(pathImage)).into(ivPlace);
        }
    }

    private void tampilkanFotoDialog(){
        AlertDialog.Builder fotoDialog = new AlertDialog.Builder(this);
        fotoDialog.setTitle("Select Action");

        // Isi opsi dialog
        String[] fotoDialogItems = {
                "Pilih foto dari gallery",
                "Ambil dari kamera" };

        fotoDialog.setItems(fotoDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int pilihan) {
                        switch (pilihan) {
                            case 0:
                                pilihDariGallery();
                                break;
                            case 1:
                                ambilDariCamera();
                                break;
                        }
                    }
                });
        fotoDialog.show();
    }

    public void pilihDariGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(galleryIntent, 13);
    }

    private void ambilDariCamera() {
        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);

        startActivityForResult(cameraIntent, 16);
    }

    public String simpanImage(Bitmap myBitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();

        // Kualitas gambar yang disimpan
        myBitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        // Buat object direktori file
        File lokasiImage = new File(
                Environment.getExternalStorageDirectory() + "/praktikum");

        // Buat direktori untuk penyimpanan
        if (!lokasiImage.exists()) {
            lokasiImage.mkdirs();
        }

        try {
            // Untuk penamaan file
            File f = new File(lokasiImage, Calendar.getInstance()
                    .getTimeInMillis() + ".jpg");
            f.createNewFile();

            // Operasi file
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            MediaScannerConnection.scanFile(this,
                    new String[]{f.getPath()},
                    new String[]{"image/jpeg"}, null);
            fo.close();

            Log.d("PRAKTIKUM", "File tersimpan di --->" + f.getAbsolutePath());

            // Return file
            return f.getAbsolutePath();

        } catch (IOException e1) {
            Log.d("PRAKTIKUM", "erroraaaaa");
            e1.printStackTrace();
        }
        return "";
    }

    // Memberi peringatan butuh permission
    private void tampilkanSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(AddPlace.this);
        builder.setTitle("Butuh Permission");
        builder.setMessage("Aplikasi ini membutuhkan permission khusus untuk menjalankan aplikasi.");
        builder.setPositiveButton("BUKA SETTINGS", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                bukaSettings();
            }
        });
        builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();

    }

    // Membuka layar Settings Android
    private void bukaSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
//        Toast.makeText(this.mContext,"Tidak Boleh Kembali, silahkan gunakan opsi menu", Toast.LENGTH_LONG).show();
    }


}
