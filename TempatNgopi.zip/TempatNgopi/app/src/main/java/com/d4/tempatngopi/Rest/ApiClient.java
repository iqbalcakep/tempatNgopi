package com.d4.tempatngopi.Rest;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    static String Ipserver = "192.168.67.228:9090";
    public static final String BASE_URL_API = "http:/"+Ipserver+"/api/";
    public static final String LOAD_URL = "http:/"+Ipserver+"/public/";
    private static Retrofit retrofit = null;

    public static Retrofit getClient() {
        if (retrofit==null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL_API)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }




}
