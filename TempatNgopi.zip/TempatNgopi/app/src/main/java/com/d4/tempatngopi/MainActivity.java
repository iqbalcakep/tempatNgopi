package com.d4.tempatngopi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.transition.Slide;
import android.widget.Button;
import android.widget.Toast;

import com.d4.tempatngopi.Adapter.PlaceAdapter;
import com.d4.tempatngopi.Model.GetPlace;
import com.d4.tempatngopi.Model.Place;
import com.d4.tempatngopi.Rest.ApiClient;
import com.d4.tempatngopi.Rest.ApiInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends OpsiMenu {

    RecyclerView mRecyclerView;
    RecyclerView.Adapter mAdapter;
    RecyclerView.LayoutManager mLayoutManager;
    Context mContext;
    ApiInterface mApiInterface;
    private SwipeRefreshLayout mSwipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mContext = this.getApplicationContext();
        mRecyclerView = (RecyclerView) findViewById(R.id.rPlace);
        mLayoutManager = new LinearLayoutManager(mContext);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mApiInterface = ApiClient.getClient().create(ApiInterface.class);
        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.refresh);
        showPlaces();

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(false);
                showPlaces();
            }
        });

    }

    private void showPlaces() {
        Call<GetPlace> mGetPlace = mApiInterface.getPlace();
        mGetPlace.enqueue(new Callback<GetPlace>() {
            @Override
            public void onResponse(Call<GetPlace> call, Response<GetPlace> response) {
                if(response.body().getStatus().equals("success")) {
                    List<Place> listKomplain = response.body().getData();
                    mAdapter = new PlaceAdapter(listKomplain, mContext);
                    mRecyclerView.setAdapter(mAdapter);
                }
            }

            @Override
            public void onFailure(Call<GetPlace> call, Throwable t) {

            }
        });
    }
}
